package com.abb.uiautomation.core.interfaces;

public interface IKeywords {
	
	//void navigate();
	void launchBrowser(String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);

	void inputText(String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	void click(String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	void isElementExist(String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);

	void navigate(String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
	
	void select(String keyword, String locatorType, String locatorValue, String testData, String expectedResult, String testStepId);
}
