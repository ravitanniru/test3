package com.abb.uiautomation.core.utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class EventExecutor {
	
	public static void navigate(WebDriver driver, String testData)
	{
		System.setProperty("webdriver.chrome.driver","C:\\JunkFolder\\ImpLibs\\chromedriver.exe");
	
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
	}
	
	public static void enterText(WebDriver driver, By obj, String testData)
	{
		driver.findElement(obj).sendKeys(testData);
	}
	
	public static void click(WebDriver driver, By obj)
	{
		driver.findElement(obj).click();
	}
	
	public static void select(WebDriver driver, By obj, String testData)
	{
		Select dropdown = new Select(driver.findElement(obj));
		dropdown.selectByVisibleText(testData);
	}
	
	public static boolean isElementExist(WebDriver driver, By obj)
	{
		System.out.println("I am in isElementExist");
		return driver.findElement(obj).isDisplayed();
		
	}

}
