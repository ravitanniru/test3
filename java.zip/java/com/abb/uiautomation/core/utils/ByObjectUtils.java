package com.abb.uiautomation.core.utils;

import org.openqa.selenium.By;

public class ByObjectUtils {
	
	public static By getByObject(String locatorType, String locatorValue)
	{
		By object = null;
		if ("xpath".equalsIgnoreCase(locatorType)) {
			object = By.xpath(locatorValue);

		} else if ("id".equalsIgnoreCase(locatorType)) {

			object = By.id(locatorValue);
		}
		return object;
	}

}
