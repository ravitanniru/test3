package com.abb.uiautomation.core.services;



public class AbbUiAutomationService {
	
	public void execute(String filePath) throws Exception {
		
		keywordInvokeService keywordInvokeService = new keywordInvokeService(new keywordService());
		keywordInvokeService.execute(filePath);
	}

	public static void main(String args[]) throws Exception {
		String filePath = "C:\\Abbuiautomation\\ABBSanityTestCases.xlsx";
		AbbUiAutomationService service = new AbbUiAutomationService();
		service.execute(filePath);
	}
}
