package com.abb.uiautomation.core.services;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.abb.uiautomation.core.interfaces.IKeywords;
import com.abb.uiautomation.core.utils.EventExecutor;
import com.abb.uiautomation.core.utils.WebDriverManager;
import com.abb.uiautomation.core.utils.ByObjectUtils;

public class keywordService implements IKeywords {

	protected WebDriver driver;

	public keywordService(WebDriver driver) {
		this.driver = driver;
	}

	public keywordService() {
		super();
	}

	
	@Override
	public void navigate(String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) {
		try {
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.get(testData);
		} catch (Exception exp) {

			throw exp;
		}

	}

	@Override
	public void inputText(String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) {
		try {
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			By element = ByObjectUtils.getByObject(locatorType, locatorValue);
			EventExecutor.enterText(driver, element, testData);
		} catch (Exception exp) {

			throw exp;
		}
	}

	@Override
	public void click(String keyword, String locatorType, String locatorValue, String testData, String expectedResult,
			String testStepId) {
		try {
			driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
			By element = ByObjectUtils.getByObject(locatorType, locatorValue);
			EventExecutor.click(driver, element);
		} catch (Exception exp) {

			throw exp;
		}

	}

	@Override
	public void isElementExist(String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) {
		try {
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			By element = ByObjectUtils.getByObject(locatorType, locatorValue);
			System.out.println("in verify ecist");
			boolean status = EventExecutor.isElementExist(driver, element);
			System.out.println("boolean  : " + status);
		} catch (Exception exp) {

			throw exp;
		}
	}

	@Override
	public void select(String keyword, String locatorType, String locatorValue, String testData, String expectedResult,
			String testStepId) {
		try {
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			By element = ByObjectUtils.getByObject(locatorType, locatorValue);
			EventExecutor.enterText(driver, element, testData);
		} catch (Exception exp) {

			throw exp;
		}
	}

	@Override
	public void launchBrowser(String keyword, String locatorType, String locatorValue, String testData,
			String expectedResult, String testStepId) {
		try {
			this.driver = WebDriverManager.getWebDriver(testData);
			this.driver.manage().window().maximize();
		} catch (Exception exp) {

			throw exp;
		}

	}

}
