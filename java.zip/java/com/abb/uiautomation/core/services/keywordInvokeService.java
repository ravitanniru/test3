package com.abb.uiautomation.core.services;

import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.abb.uiautomation.core.constants.AbbConstants;
import com.abb.uiautomation.core.interfaces.IKeywords;
import com.abb.uiautomation.core.utils.XlsxFileUtils;

public class keywordInvokeService {

	IKeywords keywords;
	XlsxFileUtils xlsxfileutils = new XlsxFileUtils();
	XSSFWorkbook workBook = new XSSFWorkbook();
	keywordService keywordservice = new keywordService();
	Method[] method;

	private int testStep;
	private int totalSteps;
	private int lastTestStep;
	private int testCaseCount;
	private String testStepId;
	private boolean res;
	private boolean bResult;

	private long day;
	private long hour;
	private long second;
	private long minute;
	private long endTime;
	private long startTime;
	private long totalTime;
	private long totalCount;
	private long batchTotalTime;

	private Date date = new Date();

	private String xpath;
	private String keyword;
	private String expectedResult;
	private String testData;
	private String locatorType;
	private String locatorValue;

	private String testSheet;
	private String timeStamp;
	private String testCaseID;
	private String controlName;
	private String controlText;
	private String totalTimeCountNew;
	private String batchtotalTimenew;

	public keywordInvokeService(IKeywords keywords) {
		this.keywords = keywords;
		method = this.keywords.getClass().getMethods();
	}

	public void execute(String filePath) throws Exception {
		runTestStep(filePath);
	}

	private int setTestCaseCount() {
		if (!res) {
			testCaseCount = 0;
			res = true;
		} else {
		}
		return testCaseCount;
	}

	public boolean runTestStep(String filePath) throws Exception {
		xlsxfileutils.setExcelFile(filePath);
		workBook = xlsxfileutils.getWorkBook();
		System.out.println("xlsxfileutils.getRowCount : " + xlsxfileutils.getRowCount("TestSuite"));
		int totalNumOfTestcases = xlsxfileutils.getRowCount("TestSuite");
		System.out.println("Total testcases : " + totalNumOfTestcases);
		int index = 0;
		if (totalNumOfTestcases != 0) {
			index = 1;
		}
		for (int i = index; i < workBook.getNumberOfSheets(); i++) {
			int iTestcase = 1;
			int iTotalTestCases = xlsxfileutils.getRowCount("TestSuite");
			System.out.println("Total testcases : " + iTotalTestCases);
			testCaseCount = 0;
			setTestCaseCount();
			bResult = true;
			testCaseID = xlsxfileutils.getCellData(iTestcase, AbbConstants.COL_TESTCASE_ID, workBook.getSheetName(i));
			// System.out.println("testCaseID:"+testCaseID);
			testSheet = workBook.getSheetName(i);
			System.out.println("testSheet:" + testSheet);
			testStepId = xlsxfileutils.getCellData(iTestcase, AbbConstants.COL_TEST_STEP_ID, workBook.getSheetName(i));
			// System.out.println("testStepId:"+testStepId);

			testStep = xlsxfileutils.getRowContains(testCaseID, AbbConstants.COL_TESTCASE_ID, workBook.getSheetName(i));
			// System.out.println("testStep"+testStep);
			// lastTestStep = xlsxfileutils.getTestStepsCount(workBook.getSheetName(i),
			// testCaseID, testStep);
			lastTestStep = xlsxfileutils.getRowCount(testSheet);
			// System.out.println("lastTestStep:"+lastTestStep);
			bResult = true;
			try {
				for (; testStep < lastTestStep; testStep++) {
					keyword = xlsxfileutils.getCellData(testStep, AbbConstants.COL_ACTION_KEYWORD,
							workBook.getSheetName(i));
					locatorType = xlsxfileutils.getCellData(testStep, AbbConstants.COL_LOCATOR_TYPE,
							workBook.getSheetName(i));
					locatorValue = xlsxfileutils.getCellData(testStep, AbbConstants.COL_LOCATOR_VALUE,
							workBook.getSheetName(i));

					testData = xlsxfileutils.getCellData(testStep, AbbConstants.COL_DATA_SET, workBook.getSheetName(i));

					expectedResult = xlsxfileutils.getCellData(testStep, AbbConstants.COL_TEST_EXP_DATA,
							workBook.getSheetName(i));
					System.out.println("keyword =" + keyword + "; locatorType=" + locatorType + "; locatorValue="
							+ locatorValue + "; testData=" + testData + "; expectedResult=" + expectedResult);
					invokeKeyword(keyword, locatorType, locatorValue, testData, expectedResult, testStepId);
				}
			} catch (Exception e) {
				e.printStackTrace();

			}
		}

		return false;
	}

	public void invokeKeyword(final String actionKeyword, final String locatorType, final String locatorValue,
			final String testData, final String expectedResult, final String testStepId) throws Exception {

		// Object object = null;

		try {
			for (int i = 0; i < method.length; i++) {
				if (method[i].getName().equals(actionKeyword)) {
					method[i].invoke(this.keywords, actionKeyword, locatorType, locatorValue, testData, expectedResult,
							testStepId);
				}
			}
		} catch (Exception e) {
			// log.error("Exception occured while executing the test case");
			throw e;
		}

		// return object;
	}
}
