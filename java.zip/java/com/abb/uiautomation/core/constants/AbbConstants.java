package com.abb.uiautomation.core.constants;

public interface AbbConstants {

	String EMPTY_STR = "";

	int COL_CONTROL = 2;
	int COL_DATA_SET = 6;
	int COL_TESTCASE_ID = 0;
	int COL_PAGE_OBJECT = 4;
	int COL_CONTROL_TEXT = 3;
	int COL_TEST_EXP_DATA = 7;
	int COL_ACTION_KEYWORD = 3;
	int COL_LOCATOR_TYPE = 4;
	int COL_LOCATOR_VALUE = 5;
	int COL_TEST_STEP_ID = 1;
	
	String FAIL = "FAIL";

}
